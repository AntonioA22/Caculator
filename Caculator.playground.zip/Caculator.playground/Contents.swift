import UIKit

var Num1 = 360
var Num2 = 52
var sub = Num1 - Num2
var add = Num1 + Num2
var multi = Num1 * Num2
var div = Num1 / Num2
print("\(Num1) + \(Num2) =\(add)")
print("\(Num1) - \(Num2) =\(sub)")
print("\(Num1) * \(Num2) =\(multi)")
print("\(Num1) / \(Num2) =\(div)")
